using System;
using System.IO;
using System.Linq;
using BibFarmacia.Clases;
using BibFarmacia.Enum;
using BibFarmacia.EstrategiasDescuento;
using BibFarmacia.Eventos;
using BibFarmacia.Fachada;
using BibFarmacia.Factories;
using BibFarmacia.Interfaces;
using BibFarmacia.Repositorios;
using BibFarmacia.Servicios;

Console.WriteLine("=================================================");
Console.WriteLine("    EJECUCIÓN DE PRUEBAS AUTOMATIZADAS RETO 2   ");
Console.WriteLine("=================================================\n");

int pasadas = 0;
int falladas = 0;

void AssertTrue(bool condition, string nombrePrueba, string detalle = "")
{
    if (condition)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"[PASS] {nombrePrueba}");
        Console.ResetColor();
        pasadas++;
    }
    else
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine($"[FAIL] {nombrePrueba} - Detalle: {detalle}");
        Console.ResetColor();
        falladas++;
    }
}

// ---------------------------------------------------------------
// 1. VERIFICACIÓN PATRÓN FACTORY METHOD (Creacional - P-02)
// ---------------------------------------------------------------
Console.WriteLine("\n--- 1. Pruebas Factory Method ---");

FabricaMedicamentoCapsula fabCapsula = new FabricaMedicamentoCapsula();
Producto capsula = fabCapsula.CrearProducto(new[] { "DolexCaps", "6000", "10", "5", "2026-10-10", "Bayer" });
AssertTrue(capsula is MedicamentoCapsula, "FabricaMedicamentoCapsula crea MedicamentoCapsula");
AssertTrue(capsula.Nombre == "DolexCaps" && capsula.Precio == 6000, "FabricaMedicamentoCapsula parsea datos correctamente");

FabricaMedicamentoLiquido fabLiquido = new FabricaMedicamentoLiquido();
Producto liquido = fabLiquido.CrearProducto(new[] { "Jarabe", "12000", "8", "4", "2026-12-10", "MK" });
AssertTrue(liquido is MedicamentoLiquido, "FabricaMedicamentoLiquido crea MedicamentoLiquido");

FabricaCosmetico fabCosmetico = new FabricaCosmetico();
Producto cosmetico = fabCosmetico.CrearProducto(new[] { "Crema", "15000", "20", "5", "2026-12-01", "Nivea" });
AssertTrue(cosmetico is Cosmetico c && c.Marca == "Nivea", "FabricaCosmetico crea Cosmetico con Marca");

FabricaComestible fabComestible = new FabricaComestible();
Producto comestible = fabComestible.CrearProducto(new[] { "Agua", "1500", "50", "10", "2026-06-01", "0" });
AssertTrue(comestible is Comestible com && com.Calorias == 0, "FabricaComestible crea Comestible con Calorías");

FabricaServicioClinico fabServicio = new FabricaServicioClinico();
ServicioClinico serv = fabServicio.CrearServicio(new[] { "Inyectologia", "15000", "Aplicacion IM" });
AssertTrue(serv.Nombre == "Inyectologia" && serv.Precio == 15000, "FabricaServicioClinico crea ServicioClinico");

// ---------------------------------------------------------------
// 2. VERIFICACIÓN SOLID: LSP & ISP PARA SC-02 (Servicios Clínicos)
// ---------------------------------------------------------------
Console.WriteLine("\n--- 2. Pruebas SOLID (LSP e ISP para SC-02) ---");

// LSP: ServicioClinico NO hereda de Producto (no tiene Stock ni Vencimiento ficticio)
AssertTrue(serv is IVendible, "ServicioClinico implementa IVendible");
AssertTrue(!((object)serv is Producto), "LSP: ServicioClinico NO es un Producto (no hereda de Producto)");

// ISP: Interfaces segregadas
IRepositorioServicioClinico repoServicioTest = new RepositorioServicioArchivo(fabServicio);
AssertTrue(repoServicioTest is IRepositorioServicioClinico, "ISP: Repositorio de servicios tiene interfaz propia y segregada");

// ---------------------------------------------------------------
// 3. VERIFICACIÓN PATRÓN STRATEGY (Comportamiento - P-05)
// ---------------------------------------------------------------
Console.WriteLine("\n--- 3. Pruebas Strategy (Descuentos) ---");

IDescuento sinDesc = new DescuentoSinDescuento();
AssertTrue(sinDesc.CalcularDescuento(10000) == 0m, "Estrategia DescuentoSinDescuento calcula 0%");

IDescuento desc10 = new ServicioDescuento();
AssertTrue(desc10.CalcularDescuento(10000) == 1000m, "Estrategia ServicioDescuento calcula 10% fijo");

IDescuento desc25 = new DescuentoPorcentaje(25m);
AssertTrue(desc25.CalcularDescuento(20000) == 5000m, "Estrategia DescuentoPorcentaje(25%) calcula 5000");

IDescuento descFijo = new DescuentoMontoFijo(3000m);
AssertTrue(descFijo.CalcularDescuento(10000) == 3000m, "Estrategia DescuentoMontoFijo calcula monto tope");
AssertTrue(descFijo.CalcularDescuento(2000) == 2000m, "Estrategia DescuentoMontoFijo no excede precio base");

// ---------------------------------------------------------------
// 4. VERIFICACIÓN PATRÓN FACADE (Estructural - P-01) Y FLUJOS
// ---------------------------------------------------------------
Console.WriteLine("\n--- 4. Pruebas Facade (FarmaciaFachada) ---");

EventoStockMinimo evStock = new EventoStockMinimo();
EventoVencimiento evVenc = new EventoVencimiento();
EventoPuntos evPuntos = new EventoPuntos();
EventoMovimiento evMov = new EventoMovimiento();

string ultimoMensajeStock = "";
evStock.StockMinimo += msg => ultimoMensajeStock = msg;

string ultimoMensajeMov = "";
evMov.MovimientoRegistrado += msg => ultimoMensajeMov = msg;

string ultimoMensajePuntos = "";
evPuntos.PuntosAcumulados += msg => ultimoMensajePuntos = msg;

RepositorioMedicamentoArchivo repoMed = new RepositorioMedicamentoArchivo(fabCapsula);
RepositorioCosmeticoArchivo repoCos = new RepositorioCosmeticoArchivo(fabCosmetico);
RepositorioComestibleArchivo repoCom = new RepositorioComestibleArchivo(fabComestible);
RepositorioClienteArchivo repoCli = new RepositorioClienteArchivo();
RepositorioUsuarioArchivo repoUsu = new RepositorioUsuarioArchivo();
RepositorioServicioArchivo repoSer = new RepositorioServicioArchivo(fabServicio);

ServicioProducto sProducto = new ServicioProducto(repoMed, evStock, evVenc);
ServicioCliente sCliente = new ServicioCliente(repoCli, evPuntos);
ServicioUsuario sUsuario = new ServicioUsuario(repoUsu);
ServicioMovimiento sMovimiento = new ServicioMovimiento(evMov);

// Crear usuarios en memoria para autenticación
sUsuario.AgregarUsuario(new Usuario("Admin", "123", "300", "admin@test.com", "admin", "1234"));
ServicioAutenticacion sAutenticacion = new ServicioAutenticacion(sUsuario.ObtenerUsuarios());

ServicioAtencionClinica sAtencion = new ServicioAtencionClinica(repoSer);

ServicioVenta sVenta = new ServicioVenta(sProducto, sMovimiento, desc10);

FarmaciaFachada fachada = new FarmaciaFachada(
    sProducto,
    sCliente,
    sUsuario,
    sVenta,
    sAutenticacion,
    sAtencion);

// DIP: La fachada recibe todo por inyección de dependencias
AssertTrue(fachada != null, "DIP: Fachada inicializada por inyección de dependencias");

// Autenticación por fachada
AssertTrue(fachada.Autenticar("admin", "1234"), "Fachada autentica usuario válido");
AssertTrue(!fachada.Autenticar("admin", "wrong"), "Fachada rechaza password incorrecta");

// Agregar elementos para prueba
Laboratorio labTest = new Laboratorio("Bayer", "Medellin", "4444444");
Producto pPrueba = fabCapsula.Crear("AspirinaTest", 10000m, 5, labTest, 2);
sProducto.AgregarProducto(pPrueba);

ServicioClinico scPrueba = fabServicio.Crear("Curaciones basicas", 20000m, "Limpieza de herida");
sAtencion.AgregarServicio(scPrueba);

Cliente cliPrueba = new Cliente("Juan Perez", "102030", "3001234567", "juan@test.com");
sCliente.AgregarCliente(cliPrueba);

// Consultas unificadas a través de la fachada
AssertTrue(fachada.BuscarProducto("AspirinaTest") != null, "Fachada busca y encuentra producto");
AssertTrue(fachada.BuscarItemVendible("Curaciones basicas") is ServicioClinico, "Fachada encuentra servicio clínico como IVendible");

// Acumular puntos por fachada
bool okPuntos = fachada.AcumularPuntos("Juan Perez", 50, out _);
AssertTrue(okPuntos && cliPrueba.Puntos == 50, "Fachada delega acumulación de puntos a ServicioCliente");
AssertTrue(ultimoMensajePuntos.Contains("Juan Perez"), "Evento de puntos disparado correctamente");

// ---------------------------------------------------------------
// 5. VERIFICACIÓN VENTA SC-02 Y APLICACIÓN DE STRATEGY
// ---------------------------------------------------------------
Console.WriteLine("\n--- 5. Pruebas Venta de Servicios y Productos con Strategy ---");

// Venta de Producto con Strategy 10%
bool ventaProdOk = fachada.RegistrarVenta("AspirinaTest", 2, out decimal subProd, out decimal descProd, out decimal totProd, out string tipoProd, out string errProd);
AssertTrue(ventaProdOk, "Venta de producto registrada exitosamente");
AssertTrue(pPrueba.Stock == 3, "Stock del producto se decrementó correctamente (5 - 2 = 3)");
AssertTrue(subProd == 20000m && descProd == 2000m && totProd == 18000m, "Estrategia 10% aplicada al total del producto");
AssertTrue(ultimoMensajeMov.Contains("Venta"), "Notificador de movimiento alertó venta de producto");

// Venta de Servicio Clínico SC-02 con Strategy 10%
bool ventaServOk = fachada.RegistrarVenta("Curaciones basicas", 1, out decimal subServ, out decimal descServ, out decimal totServ, out string tipoServ, out string errServ);
AssertTrue(ventaServOk, "Venta de servicio clínico registrada exitosamente");
AssertTrue(tipoServ == "Servicio", "La venta identificó el ítem como Servicio");
AssertTrue(subServ == 20000m && descServ == 2000m && totServ == 18000m, "Estrategia 10% aplicada al servicio clínico");
AssertTrue(ultimoMensajeMov.Contains("Venta"), "Notificador de movimiento alertó venta de servicio clínico");

// Cambio dinámico de Strategy a 25% y nueva venta
fachada.EstablecerEstrategiaDescuento(desc25);
AssertTrue(fachada.ObtenerEstrategiaDescuento() == desc25, "Estrategia cambiada dinámicamente en tiempo de ejecución");

bool ventaServ25 = fachada.RegistrarVenta("Curaciones basicas", 1, out decimal sub25, out decimal desc25Val, out decimal tot25, out _, out _);
AssertTrue(ventaServ25 && desc25Val == 5000m && tot25 == 15000m, "Nueva estrategia (25%) aplicada a la venta subsiguiente");

// Validación de stock insuficiente en producto
bool ventaInsuficiente = fachada.RegistrarVenta("AspirinaTest", 100, out _, out _, out _, out _, out string errInsuf);
AssertTrue(!ventaInsuficiente && errInsuf.Contains("insuficiente"), "Venta con stock insuficiente es rechazada limpiamente");

// Movimiento de servicio preserva compatibilidad con Producto (retorna null si es servicio)
Movimiento movServ = new Movimiento(DateTime.Now, 1, "Venta", scPrueba);
AssertTrue(movServ.Item is ServicioClinico, "Movimiento registra ServicioClinico como IVendible");
AssertTrue(movServ.Producto == null, "Movimiento.Producto es null para servicios sin lanzar excepción");

// ---------------------------------------------------------------
// RESUMEN FINAL
// ---------------------------------------------------------------
Console.WriteLine("\n=================================================");
Console.WriteLine($"RESULTADO: {pasadas} pasadas, {falladas} falladas");
Console.WriteLine("=================================================");

if (falladas > 0)
{
    Environment.Exit(1);
}
