using System;
using System.Collections.Generic;
using BibFarmacia.Clases;
using BibFarmacia.Eventos;
using BibFarmacia.Fachada;
using BibFarmacia.Interfaces;
using BibFarmacia.Repositorios;
using BibFarmacia.Servicios;

Console.Title = "Sistema Farmacia";

// ================= COMPOSITION ROOT (WIRING) =================

// 1. Notificadores y Eventos
EventoStockMinimo eventoStock = new EventoStockMinimo();
EventoVencimiento eventoVencimiento = new EventoVencimiento();
EventoPuntos eventoPuntos = new EventoPuntos();
EventoMovimiento eventoMovimiento = new EventoMovimiento();

eventoStock.StockMinimo += mensaje =>
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine(mensaje);
    Console.ResetColor();
};

eventoVencimiento.Vencimiento += mensaje =>
{
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine(mensaje);
    Console.ResetColor();
};

eventoPuntos.PuntosAcumulados += mensaje =>
{
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine(mensaje);
    Console.ResetColor();
};

eventoMovimiento.MovimientoRegistrado += mensaje =>
{
    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.WriteLine(mensaje);
    Console.ResetColor();
};

// 2. Repositorios (utilizan internamente Factory Method)
RepositorioMedicamentoArchivo repoProducto = new RepositorioMedicamentoArchivo();
RepositorioCosmeticoArchivo repoCosmetico = new RepositorioCosmeticoArchivo();
RepositorioComestibleArchivo repoComestible = new RepositorioComestibleArchivo();
RepositorioClienteArchivo repoCliente = new RepositorioClienteArchivo();
RepositorioUsuarioArchivo repoUsuario = new RepositorioUsuarioArchivo();
RepositorioServicioArchivo repoServicio = new RepositorioServicioArchivo();

// 3. Servicios de Dominio / Aplicación
ServicioProducto servicioProducto = new ServicioProducto(
    repoProducto,
    eventoStock,
    eventoVencimiento);

ServicioCliente servicioCliente = new ServicioCliente(
    repoCliente,
    eventoPuntos);

ServicioUsuario servicioUsuario = new ServicioUsuario(repoUsuario);

ServicioMovimiento servicioMovimiento = new ServicioMovimiento(eventoMovimiento);

ServicioAutenticacion servicioAutenticacion = new ServicioAutenticacion(
    servicioUsuario.ObtenerUsuarios());

ServicioAtencionClinica servicioAtencionClinica = new ServicioAtencionClinica(repoServicio);

// 4. Estrategia de Descuento (Patrón Strategy)
IDescuento estrategiaDescuento = new ServicioDescuento(); // Descuento base del 10%

// 4.1 Servicio de Venta (orquesta stock + movimiento + descuento; la fachada no calcula nada)
ServicioVenta servicioVenta = new ServicioVenta(
    servicioProducto,
    servicioMovimiento,
    estrategiaDescuento);

// 5. Fachada Principal (Patrón Facade con DI estricto)
FarmaciaFachada farmaciaFachada = new FarmaciaFachada(
    servicioProducto,
    servicioCliente,
    servicioUsuario,
    servicioVenta,
    servicioAutenticacion,
    servicioAtencionClinica);

// ================= CARGA TXT =================

Console.ForegroundColor = ConsoleColor.DarkGreen;
Console.WriteLine("Cargando información del sistema...\n");
Console.ResetColor();

var resultadosCarga = farmaciaFachada.CargarDatosSistema(
    "productos.txt",
    repoCosmetico,
    "cosmeticos.txt",
    repoComestible,
    "comestibles.txt",
    "clientes.txt",
    "usuarios.txt",
    "servicios.txt");

Console.WriteLine(resultadosCarga["Productos"]);
Console.WriteLine(resultadosCarga["Cosmeticos"]);
Console.WriteLine(resultadosCarga["Comestibles"]);
Console.WriteLine(resultadosCarga["Clientes"]);
Console.WriteLine(resultadosCarga["Usuarios"]);
Console.WriteLine();

// ================= LOGIN =================

Console.ForegroundColor = ConsoleColor.Blue;
Console.WriteLine("=========== LOGIN ===========");
Console.ResetColor();

Console.Write("Usuario: ");
string user = Console.ReadLine()?.Trim().Trim('\uFEFF') ?? string.Empty;

Console.Write("Contraseña: ");
string password = Console.ReadLine()?.Trim().Trim('\uFEFF') ?? string.Empty;

bool login = farmaciaFachada.Autenticar(user, password);

if (!login)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("\nAcceso denegado");
    Console.ResetColor();
    return;
}

Console.ForegroundColor = ConsoleColor.Green;
Console.WriteLine("\nLogin correcto");
Console.ResetColor();

// ================= ALERTAS =================

farmaciaFachada.VerificarAlertas();

// ================= MENÚ =================

int opcion = 0;

while (opcion != 7)
{
    Console.ForegroundColor = ConsoleColor.Magenta;
    Console.WriteLine("\n==============================");
    Console.WriteLine("      SISTEMA FARMACIA");
    Console.WriteLine("==============================");
    Console.ResetColor();

    Console.WriteLine("1. Ver productos");
    Console.WriteLine("2. Ver clientes");
    Console.WriteLine("3. Buscar producto");
    Console.WriteLine("4. Registrar venta");
    Console.WriteLine("5. Acumular puntos");
    Console.WriteLine("6. Ver alertas");
    Console.WriteLine("7. Salir");
    Console.WriteLine("8. Ver servicios clínicos (SC-02)");

    Console.Write("\nSeleccione opción: ");

    if (!int.TryParse(Console.ReadLine(), out opcion))
    {
        Console.WriteLine("\nOpción inválida");
        continue;
    }

    switch (opcion)
    {
        case 1:
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n===== PRODUCTOS =====");
            Console.ResetColor();

            Console.WriteLine("Nombre\t\tStock\tPrecio");
            Console.WriteLine("-----------------------------------");

            foreach (var producto in farmaciaFachada.ObtenerProductos())
            {
                Console.WriteLine($"{producto.Nombre}\t\t{producto.Stock}\t{producto.Precio}");
            }
            break;

        case 2:
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n===== CLIENTES =====");
            Console.ResetColor();

            foreach (var cliente in farmaciaFachada.ObtenerClientes())
            {
                Console.WriteLine($"{cliente.Nombre} - Puntos: {cliente.Puntos}");
            }
            break;

        case 3:
            Console.Write("\nIngrese nombre producto: ");
            string nombre = Console.ReadLine()!;

            var itemBuscado = farmaciaFachada.BuscarItemVendible(nombre);

            if (itemBuscado is Producto productoBuscado)
            {
                Console.WriteLine($"\nProducto: {productoBuscado.Nombre}");
                Console.WriteLine($"Precio: {productoBuscado.Precio}");
                Console.WriteLine($"Stock: {productoBuscado.Stock}");
            }
            else if (itemBuscado is ServicioClinico servicioBuscado)
            {
                Console.WriteLine($"\nServicio: {servicioBuscado.Nombre}");
                Console.WriteLine($"Precio: {servicioBuscado.Precio}");
                Console.WriteLine($"Descripción: {servicioBuscado.Descripcion}");
            }
            else
            {
                Console.WriteLine("\nProducto no encontrado");
            }
            break;

        case 4:
            Console.Write("\nNombre producto: ");
            string nombreVenta = Console.ReadLine()!;

            var itemExistente = farmaciaFachada.BuscarItemVendible(nombreVenta);
            if (itemExistente != null)
            {
                Console.Write("Cantidad: ");
                if (!int.TryParse(Console.ReadLine(), out int cantidad) || cantidad <= 0)
                {
                    Console.WriteLine("\nCantidad inválida");
                    break;
                }

                bool exito = farmaciaFachada.RegistrarVenta(
                    nombreVenta,
                    cantidad,
                    out decimal subtotal,
                    out decimal descuento,
                    out decimal total,
                    out string tipo,
                    out string error);

                if (exito)
                {
                    Console.WriteLine("\nVenta registrada");
                    if (descuento > 0)
                    {
                        Console.WriteLine($"Subtotal: {subtotal:N0} | Descuento: {descuento:N0} | Total a pagar: {total:N0}");
                    }
                }
                else
                {
                    Console.WriteLine($"\n{error}");
                }
            }
            else
            {
                Console.WriteLine("\nProducto no encontrado");
            }
            break;

        case 5:
            Console.Write("\nNombre cliente: ");
            string nombreCliente = Console.ReadLine()!;

            var clientePuntos = farmaciaFachada
                .ObtenerClientes()
                .Find(c => c.Nombre.Equals(nombreCliente, StringComparison.OrdinalIgnoreCase));

            if (clientePuntos != null)
            {
                Console.Write("Puntos: ");
                int puntos = int.Parse(Console.ReadLine()!);

                farmaciaFachada.AcumularPuntos(clientePuntos.Nombre, puntos, out _);
            }
            else
            {
                Console.WriteLine("\nCliente no encontrado");
            }
            break;

        case 6:
            Console.WriteLine("\nVerificando alertas...");
            farmaciaFachada.VerificarAlertas();
            break;

        case 7:
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\nSaliendo del sistema...");
            Console.ResetColor();
            break;

        case 8:
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("\n===== SERVICIOS CLÍNICOS (SC-02) =====");
            Console.ResetColor();
            Console.WriteLine("Nombre\t\t\tPrecio\tDescripción");
            Console.WriteLine("------------------------------------------------------------------");
            foreach (var servicio in farmaciaFachada.ObtenerServiciosClinicos())
            {
                Console.WriteLine($"{servicio.Nombre,-22}\t{servicio.Precio}\t{servicio.Descripcion}");
            }
            break;

        default:
            Console.WriteLine("\nOpción inválida");
            break;
    }
}

Console.WriteLine("\nFIN DEL SISTEMA");