using System;

namespace BibFarmacia.Interfaces
{
    public interface IVendible
    {
        string Nombre { get; }
        decimal Precio { get; }
        void MostrarInformacion();
    }
}
