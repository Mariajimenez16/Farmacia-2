using System.Collections.Generic;
using BibFarmacia.Clases;

namespace BibFarmacia.Interfaces
{
    public interface IRepositorioServicioClinico
    {
        bool Existe(string ruta);
        IEnumerable<ServicioClinico> LeerServicios(string ruta);
    }
}
