﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BibFarmacia.Clases;
using BibFarmacia.Interfaces;

namespace BibFarmacia.Eventos
{
    public class EventoStockMinimo : INotificadorStockMinimo
    {
        public delegate void DelegadoStock(
            string mensaje);

        public event DelegadoStock? StockMinimo;

        public void Disparar(
            Producto producto)
        {
            StockMinimo?.Invoke(
                $"ALERTA: stock mínimo de {producto.Nombre}");
        }

        public void NotificarStockMinimo(
            Producto producto)
        {
            Disparar(producto);
        }
    }
}