using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibFarmacia.Clases
{
    public class Cosmetico : Producto
    {
        public string Marca { get; set; }
 
        public Cosmetico(
            string nombre,
            decimal precio,
            int stock,
            int stockMinimo,
            DateTime fechaVencimiento,
            string marca)
            : base(nombre, precio, stock,
                  stockMinimo, fechaVencimiento)
        {
            Marca = marca;
        }
    }
}