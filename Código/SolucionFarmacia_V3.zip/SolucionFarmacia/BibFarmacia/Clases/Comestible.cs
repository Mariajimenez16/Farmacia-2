using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibFarmacia.Clases

{

    public class Comestible : Producto
    {
        public int Calorias { get; set; }

        public Comestible(string nombre, decimal precio, int stock, int stockMinimo,
                DateTime fechaVencimiento, int calorias)

            : base(nombre, precio, stock,
                stockMinimo, fechaVencimiento)

        {
            Calorias = calorias;
        }

    }

}
 