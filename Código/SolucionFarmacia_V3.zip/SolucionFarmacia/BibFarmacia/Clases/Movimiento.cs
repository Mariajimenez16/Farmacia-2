using System;
using BibFarmacia.Interfaces;

namespace BibFarmacia.Clases
{
    public class Movimiento
    {
        public DateTime Fecha { get; set; }
        public int Cantidad { get; set; }
        public string Tipo { get; set; }
        public IVendible Item { get; set; }
        public Producto? Producto => Item as Producto;

        public Movimiento(DateTime fecha,
            int cantidad,
            string tipo,
            IVendible item)
        {
            Fecha = fecha;
            Cantidad = cantidad;
            Tipo = tipo;
            Item = item;
        }

        public Movimiento(DateTime fecha,
            int cantidad,
            string tipo,
            Producto producto) : this(fecha, cantidad, tipo, (IVendible)producto)
        {
        }
    }
}