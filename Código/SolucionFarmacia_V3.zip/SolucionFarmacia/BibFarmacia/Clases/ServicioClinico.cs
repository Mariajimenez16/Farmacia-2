using System;
using BibFarmacia.Interfaces;

namespace BibFarmacia.Clases
{
    public class ServicioClinico : IVendible
    {
        public string Nombre { get; set; }
        public decimal Precio { get; set; }
        public string Descripcion { get; set; }

        public ServicioClinico(string nombre, decimal precio, string descripcion)
        {
            Nombre = nombre;
            Precio = precio;
            Descripcion = descripcion;
        }

        public virtual void MostrarInformacion()
        {
            Console.WriteLine($"Servicio: {Nombre}");
            Console.WriteLine($"Precio: {Precio}");
            Console.WriteLine($"Descripción: {Descripcion}");
        }
    }
}
