﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BibFarmacia.Clases;
using BibFarmacia.Interfaces;
using BibFarmacia.Eventos;

namespace BibFarmacia.Servicios
{
    public class ServicioProducto
    {
        private readonly List<Producto> productos;
        private readonly IRepositorioProducto repositorio;
        private readonly INotificadorStockMinimo notificadorStock;
        private readonly INotificadorVencimiento notificadorVencimiento;

        public ServicioProducto(
            IRepositorioProducto repositorio,
            INotificadorStockMinimo notificadorStock,
            INotificadorVencimiento notificadorVencimiento)
        {
            productos = new List<Producto>();
            this.repositorio = repositorio;
            this.notificadorStock = notificadorStock;
            this.notificadorVencimiento = notificadorVencimiento;
        }

        public string AgregarProducto(
            Producto producto)
        {
            try
            {
                productos.Add(producto);

                return "Producto agregado";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public List<Producto> ObtenerProductos()
        {
            return productos;
        }

        public bool DescontarStock(Producto producto, int cantidad, out string mensajeError)
        {
            if (producto == null) throw new ArgumentNullException(nameof(producto));

            if (producto.Stock < cantidad)
            {
                mensajeError = $"Stock insuficiente. Disponible: {producto.Stock}";
                return false;
            }

            producto.Stock -= cantidad;
            mensajeError = string.Empty;
            return true;
        }

        public void VerificarStock()
        {
            foreach (var producto in productos)
            {
                if (producto.Stock <=
                    producto.StockMinimo)
                {
                    notificadorStock
                        .NotificarStockMinimo(producto);
                }
            }
        }

        public void VerificarVencimiento()
        {
            foreach (var producto in productos)
            {
                int dias =
                    (producto.FechaVencimiento -
                    DateTime.Now).Days;

                if (dias <= 30)
                {
                    notificadorVencimiento
                        .NotificarVencimiento(producto);
                }
            }
        }

        public string CargarDesdeArchivo(string ruta)
        {
            return CargarDesdeArchivo(repositorio, ruta);
        }

        public string CargarDesdeArchivo(IRepositorioProducto repo, string ruta)
        {
            try
            {
                if (!repo.Existe(ruta))
                {
                    return "Archivo no encontrado";
                }

                foreach (var producto in
                    repo.LeerProductos(ruta))
                {
                    productos.Add(producto);
                }

                return "Productos cargados";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}