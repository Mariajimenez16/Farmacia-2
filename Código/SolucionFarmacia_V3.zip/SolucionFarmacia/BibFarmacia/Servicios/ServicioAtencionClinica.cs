using System;
using System.Collections.Generic;
using System.Linq;
using BibFarmacia.Clases;
using BibFarmacia.Interfaces;

namespace BibFarmacia.Servicios
{
    public class ServicioAtencionClinica
    {
        private readonly List<ServicioClinico> servicios;
        private readonly IRepositorioServicioClinico repositorio;

        public ServicioAtencionClinica(IRepositorioServicioClinico repositorio)
        {
            servicios = new List<ServicioClinico>();
            this.repositorio = repositorio;
        }

        public string AgregarServicio(ServicioClinico servicio)
        {
            try
            {
                servicios.Add(servicio);
                return "Servicio agregado";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public List<ServicioClinico> ObtenerServicios()
        {
            return servicios;
        }

        public ServicioClinico? BuscarServicio(string nombre)
        {
            return servicios.FirstOrDefault(s =>
                s.Nombre.Contains(nombre, StringComparison.OrdinalIgnoreCase));
        }

        public string Cargar(string ruta)
        {
            try
            {
                if (!repositorio.Existe(ruta))
                {
                    return "Archivo no encontrado";
                }

                foreach (var servicio in repositorio.LeerServicios(ruta))
                {
                    servicios.Add(servicio);
                }

                return "Servicios cargados";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}
