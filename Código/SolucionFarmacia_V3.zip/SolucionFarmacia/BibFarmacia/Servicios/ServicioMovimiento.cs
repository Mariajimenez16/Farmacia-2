﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BibFarmacia.Clases;
using BibFarmacia.Interfaces;

namespace BibFarmacia.Servicios
{
    public class ServicioMovimiento
    {
        private List<Movimiento> movimientos;
        private readonly INotificadorMovimiento notificadorMovimiento;

        public ServicioMovimiento(
            INotificadorMovimiento notificadorMovimiento)
        {
            movimientos = new List<Movimiento>();
            this.notificadorMovimiento = notificadorMovimiento;
        }

        public void RegistrarMovimiento(
            Movimiento movimiento)
        {
            movimientos.Add(movimiento);

            notificadorMovimiento
                .NotificarMovimiento(movimiento.Tipo);
        }

        public List<Movimiento>
            ObtenerMovimientos()
        {
            return movimientos;
        }
    }
}