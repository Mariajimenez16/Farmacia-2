using System;
using BibFarmacia.Clases;
using BibFarmacia.Interfaces;

namespace BibFarmacia.Servicios
{
    public class ServicioVenta
    {
        private readonly ServicioProducto servicioProducto;
        private readonly ServicioMovimiento servicioMovimiento;
        private IDescuento estrategiaDescuento;

        public ServicioVenta(
            ServicioProducto servicioProducto,
            ServicioMovimiento servicioMovimiento,
            IDescuento estrategiaDescuento)
        {
            this.servicioProducto = servicioProducto ?? throw new ArgumentNullException(nameof(servicioProducto));
            this.servicioMovimiento = servicioMovimiento ?? throw new ArgumentNullException(nameof(servicioMovimiento));
            this.estrategiaDescuento = estrategiaDescuento ?? throw new ArgumentNullException(nameof(estrategiaDescuento));
        }

        public void EstablecerEstrategiaDescuento(IDescuento nuevaEstrategia)
        {
            estrategiaDescuento = nuevaEstrategia ?? throw new ArgumentNullException(nameof(nuevaEstrategia));
        }

        public IDescuento ObtenerEstrategiaDescuento()
        {
            return estrategiaDescuento;
        }

        public bool RegistrarVenta(
            IVendible? item,
            int cantidad,
            out decimal totalSinDescuento,
            out decimal descuentoCalculado,
            out decimal totalAPagar,
            out string tipoItem,
            out string mensajeError)
        {
            totalSinDescuento = 0m;
            descuentoCalculado = 0m;
            totalAPagar = 0m;
            tipoItem = string.Empty;
            mensajeError = string.Empty;

            if (item == null)
            {
                mensajeError = "Producto no encontrado";
                return false;
            }

            if (item is Producto producto)
            {
                tipoItem = "Producto";

                if (!servicioProducto.DescontarStock(producto, cantidad, out mensajeError))
                {
                    return false;
                }

                Movimiento venta = new Movimiento(DateTime.Now, cantidad, "Venta", producto);
                servicioMovimiento.RegistrarMovimiento(venta);
            }
            else if (item is ServicioClinico servicio)
            {
                tipoItem = "Servicio";
                Movimiento venta = new Movimiento(DateTime.Now, cantidad, "Venta", servicio);
                servicioMovimiento.RegistrarMovimiento(venta);
            }

            totalSinDescuento = item.Precio * cantidad;
            descuentoCalculado = estrategiaDescuento.CalcularDescuento(totalSinDescuento);
            totalAPagar = Math.Max(0m, totalSinDescuento - descuentoCalculado);

            return true;
        }
    }
}
