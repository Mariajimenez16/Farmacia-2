using BibFarmacia.Aspectos;
using BibFarmacia.Clases;

namespace BibFarmacia.Servicios
{
    public class ServicioAutenticacion
    {
        private readonly List<Usuario> usuarios;

        public ServicioAutenticacion(
            List<Usuario> usuarios)
        {
            this.usuarios = usuarios;
        }

        public bool Login(
            string user,
            string password)
        {
            return AspectoAutenticacion.Login(
                usuarios,
                user,
                password);
        }
    }
}