﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BibFarmacia.Clases;
using BibFarmacia.Interfaces;

namespace BibFarmacia.Servicios
{
    public class ServicioUsuario
    {
        private List<Usuario> usuarios;
        private readonly IRepositorioUsuario repositorio;

        public ServicioUsuario(
            IRepositorioUsuario repositorio)
        {
            usuarios = new List<Usuario>();
            this.repositorio = repositorio;
        }

        public void AgregarUsuario(
            Usuario usuario)
        {
            usuarios.Add(usuario);
        }

        public List<Usuario> ObtenerUsuarios()
        {
            return usuarios;
        }

        public string Cargar(
            string ruta)
        {
            try
            {
                if (!repositorio.Existe(ruta))
                {
                    return "Archivo no encontrado";
                }

                foreach (var usuario in
                    repositorio.LeerUsuarios(ruta))
                {
                    usuarios.Add(usuario);
                }

                return "Usuarios cargados";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}