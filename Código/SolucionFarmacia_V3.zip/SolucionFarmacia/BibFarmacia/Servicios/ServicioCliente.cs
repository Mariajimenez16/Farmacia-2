﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BibFarmacia.Clases;
using BibFarmacia.Interfaces;

namespace BibFarmacia.Servicios
{
    public class ServicioCliente
    {
        private List<Cliente> clientes;
        private readonly IRepositorioCliente repositorio;
        private readonly INotificadorPuntos notificadorPuntos;

        public ServicioCliente(
            IRepositorioCliente repositorio,
            INotificadorPuntos notificadorPuntos)
        {
            clientes = new List<Cliente>();
            this.repositorio = repositorio;
            this.notificadorPuntos = notificadorPuntos;
        }

        public void AgregarCliente(
            Cliente cliente)
        {
            clientes.Add(cliente);
        }

        public List<Cliente> ObtenerClientes()
        {
            return clientes;
        }

        public void AcumularPuntos(
            Cliente cliente,
            int puntos)
        {
            cliente.Puntos += puntos;

            notificadorPuntos.NotificarPuntos(
                cliente.Nombre,
                puntos);
        }

        public string Cargar(
            string ruta)
        {
            try
            {
                if (!repositorio.Existe(ruta))
                {
                    return "Archivo no encontrado";
                }

                foreach (var cliente in
                    repositorio.LeerClientes(ruta))
                {
                    clientes.Add(cliente);
                }

                return "Clientes cargados";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}