using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BibFarmacia.Clases;

namespace BibFarmacia.Aspectos
{
    public static class AspectoAutenticacion
    {
        public static bool Login(
            List<Usuario> usuarios,
            string user,
            string password)
        {
            if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(password))
                return false;

            string cleanUser = user.Trim().Trim('\uFEFF');
            string cleanPass = password.Trim().Trim('\uFEFF');

            return usuarios.Any(u =>
                u.UserName.Trim().Trim('\uFEFF') == cleanUser &&
                u.Password.Trim().Trim('\uFEFF') == cleanPass);
        }
    }
}