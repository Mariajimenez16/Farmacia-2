using System;
using BibFarmacia.Interfaces;

namespace BibFarmacia.EstrategiasDescuento
{
    public class DescuentoPorcentaje : IDescuento
    {
        private readonly decimal porcentaje;

        public DescuentoPorcentaje(decimal porcentaje)
        {
            if (porcentaje < 0 || porcentaje > 100)
            {
                throw new ArgumentOutOfRangeException(nameof(porcentaje), "El porcentaje debe estar entre 0 y 100.");
            }
            this.porcentaje = porcentaje;
        }

        public decimal CalcularDescuento(decimal precio)
        {
            return precio * (porcentaje / 100m);
        }
    }
}
