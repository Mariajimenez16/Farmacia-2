using BibFarmacia.Interfaces;

namespace BibFarmacia.EstrategiasDescuento
{
    public class DescuentoSinDescuento : IDescuento
    {
        public decimal CalcularDescuento(decimal precio)
        {
            return 0m;
        }
    }
}
