using System;
using BibFarmacia.Interfaces;

namespace BibFarmacia.EstrategiasDescuento
{
    public class DescuentoMontoFijo : IDescuento
    {
        private readonly decimal monto;

        public DescuentoMontoFijo(decimal monto)
        {
            if (monto < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(monto), "El monto no puede ser negativo.");
            }
            this.monto = monto;
        }

        public decimal CalcularDescuento(decimal precio)
        {
            return Math.Min(precio, monto);
        }
    }
}
