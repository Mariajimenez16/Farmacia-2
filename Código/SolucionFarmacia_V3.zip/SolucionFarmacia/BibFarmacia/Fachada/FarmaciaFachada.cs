using System;
using System.Collections.Generic;
using System.Linq;
using BibFarmacia.Clases;
using BibFarmacia.Interfaces;
using BibFarmacia.Repositorios;
using BibFarmacia.Servicios;

namespace BibFarmacia.Fachada
{
    public class FarmaciaFachada
    {
        private readonly ServicioProducto servicioProducto;
        private readonly ServicioCliente servicioCliente;
        private readonly ServicioUsuario servicioUsuario;
        private readonly ServicioVenta servicioVenta;
        private readonly ServicioAutenticacion servicioAutenticacion;
        private readonly ServicioAtencionClinica servicioAtencionClinica;

        public FarmaciaFachada(
            ServicioProducto servicioProducto,
            ServicioCliente servicioCliente,
            ServicioUsuario servicioUsuario,
            ServicioVenta servicioVenta,
            ServicioAutenticacion servicioAutenticacion,
            ServicioAtencionClinica servicioAtencionClinica)
        {
            this.servicioProducto = servicioProducto ?? throw new ArgumentNullException(nameof(servicioProducto));
            this.servicioCliente = servicioCliente ?? throw new ArgumentNullException(nameof(servicioCliente));
            this.servicioUsuario = servicioUsuario ?? throw new ArgumentNullException(nameof(servicioUsuario));
            this.servicioVenta = servicioVenta ?? throw new ArgumentNullException(nameof(servicioVenta));
            this.servicioAutenticacion = servicioAutenticacion ?? throw new ArgumentNullException(nameof(servicioAutenticacion));
            this.servicioAtencionClinica = servicioAtencionClinica ?? throw new ArgumentNullException(nameof(servicioAtencionClinica));
        }

        public void EstablecerEstrategiaDescuento(IDescuento nuevaEstrategia)
        {
            servicioVenta.EstablecerEstrategiaDescuento(nuevaEstrategia);
        }

        public IDescuento ObtenerEstrategiaDescuento()
        {
            return servicioVenta.ObtenerEstrategiaDescuento();
        }

        public Dictionary<string, string> CargarDatosSistema(
            string rutaProductos,
            IRepositorioProducto repoCosmeticos,
            string rutaCosmeticos,
            IRepositorioProducto repoComestibles,
            string rutaComestibles,
            string rutaClientes,
            string rutaUsuarios,
            string rutaServicios)
        {
            var resultados = new Dictionary<string, string>
            {
                ["Productos"] = servicioProducto.CargarDesdeArchivo(rutaProductos),
                ["Cosmeticos"] = servicioProducto.CargarDesdeArchivo(repoCosmeticos, rutaCosmeticos),
                ["Comestibles"] = servicioProducto.CargarDesdeArchivo(repoComestibles, rutaComestibles),
                ["Clientes"] = servicioCliente.Cargar(rutaClientes),
                ["Usuarios"] = servicioUsuario.Cargar(rutaUsuarios),
                ["Servicios"] = servicioAtencionClinica.Cargar(rutaServicios)
            };

            return resultados;
        }

        public bool Autenticar(string usuario, string password)
        {
            return servicioAutenticacion.Login(usuario?.Trim() ?? string.Empty, password?.Trim() ?? string.Empty);
        }

        public void VerificarAlertas()
        {
            servicioProducto.VerificarStock();
            servicioProducto.VerificarVencimiento();
        }

        public List<Producto> ObtenerProductos()
        {
            return servicioProducto.ObtenerProductos();
        }

        public List<Cliente> ObtenerClientes()
        {
            return servicioCliente.ObtenerClientes();
        }

        public List<ServicioClinico> ObtenerServicios()
        {
            return servicioAtencionClinica.ObtenerServicios();
        }

        public List<ServicioClinico> ObtenerServiciosClinicos()
        {
            return ObtenerServicios();
        }

        public Producto? BuscarProducto(string nombre)
        {
            return servicioProducto
                .ObtenerProductos()
                .FirstOrDefault(p => p.Nombre.Contains(nombre, StringComparison.OrdinalIgnoreCase));
        }

        public IVendible? BuscarItemVendible(string nombre)
        {
            var producto = BuscarProducto(nombre);
            if (producto != null) return producto;

            return servicioAtencionClinica.BuscarServicio(nombre);
        }

        public bool RegistrarVenta(
            string nombreItem,
            int cantidad,
            out decimal totalSinDescuento,
            out decimal descuentoCalculado,
            out decimal totalAPagar,
            out string tipoItem,
            out string mensajeError)
        {
            var item = BuscarItemVendible(nombreItem);

            return servicioVenta.RegistrarVenta(
                item,
                cantidad,
                out totalSinDescuento,
                out descuentoCalculado,
                out totalAPagar,
                out tipoItem,
                out mensajeError);
        }

        public bool AcumularPuntos(string nombreCliente, int puntos, out string mensaje)
        {
            var cliente = servicioCliente
                .ObtenerClientes()
                .FirstOrDefault(c => c.Nombre.Contains(nombreCliente, StringComparison.OrdinalIgnoreCase));

            if (cliente == null)
            {
                mensaje = "Cliente no encontrado";
                return false;
            }

            servicioCliente.AcumularPuntos(cliente, puntos);
            mensaje = "Puntos acumulados correctamente";
            return true;
        }
    }
}
