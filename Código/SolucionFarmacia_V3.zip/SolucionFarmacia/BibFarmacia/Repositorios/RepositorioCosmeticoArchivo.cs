using System.Collections.Generic;
using System.IO;
using BibFarmacia.Clases;
using BibFarmacia.Factories;
using BibFarmacia.Interfaces;

namespace BibFarmacia.Repositorios
{
    public class RepositorioCosmeticoArchivo : IRepositorioProducto
    {
        private readonly FabricaProducto fabrica;

        public RepositorioCosmeticoArchivo(FabricaProducto? fabrica = null)
        {
            this.fabrica = fabrica ?? new FabricaCosmetico();
        }

        public bool Existe(string ruta)
        {
            return File.Exists(ruta);
        }

        public IEnumerable<Producto> LeerProductos(string ruta)
        {
            string[] lineas = File.ReadAllLines(ruta);

            foreach (string linea in lineas)
            {
                string[] datos = linea.Split(';');
                yield return fabrica.CrearProducto(datos);
            }
        }
    }
}