using BibFarmacia.Clases;
using BibFarmacia.Interfaces;

namespace BibFarmacia.Repositorios
{
    public class RepositorioClienteArchivo : IRepositorioCliente
    {
        public bool Existe(string ruta)
        {
            return File.Exists(ruta);
        }

        public IEnumerable<Cliente> LeerClientes(
            string ruta)
        {
            string[] lineas = File.ReadAllLines(ruta);

            foreach (string linea in lineas)
            {
                string[] datos = linea.Split(';');

                yield return new Cliente(
                    datos[0],
                    datos[1],
                    datos[2],
                    datos[3]);
            }
        }
    }
}