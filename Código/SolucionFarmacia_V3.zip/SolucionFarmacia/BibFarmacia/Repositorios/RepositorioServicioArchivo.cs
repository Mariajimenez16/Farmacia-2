using System.Collections.Generic;
using System.IO;
using BibFarmacia.Clases;
using BibFarmacia.Factories;
using BibFarmacia.Interfaces;

namespace BibFarmacia.Repositorios
{
    public class RepositorioServicioArchivo : IRepositorioServicioClinico
    {
        private readonly FabricaServicio fabrica;

        public RepositorioServicioArchivo(FabricaServicio? fabrica = null)
        {
            this.fabrica = fabrica ?? new FabricaServicioClinico();
        }

        public bool Existe(string ruta)
        {
            return File.Exists(ruta);
        }

        public IEnumerable<ServicioClinico> LeerServicios(string ruta)
        {
            string[] lineas = File.ReadAllLines(ruta);

            foreach (string linea in lineas)
            {
                if (string.IsNullOrWhiteSpace(linea)) continue;
                string[] datos = linea.Split(';');
                yield return fabrica.CrearServicio(datos);
            }
        }
    }
}
