using BibFarmacia.Clases;
using BibFarmacia.Interfaces;

namespace BibFarmacia.Repositorios
{
    public class RepositorioUsuarioArchivo : IRepositorioUsuario
    {
        public bool Existe(string ruta)
        {
            return File.Exists(ruta);
        }

        public IEnumerable<Usuario> LeerUsuarios(
            string ruta)
        {
            string[] lineas = File.ReadAllLines(ruta);

            foreach (string linea in lineas)
            {
                string[] datos = linea.Split(';');

                yield return new Usuario(
                    datos[0],
                    datos[1],
                    datos[2],
                    datos[3],
                    datos[4],
                    datos[5]);
            }
        }
    }
}