using System;
using BibFarmacia.Clases;

namespace BibFarmacia.Factories
{
    public abstract class FabricaServicio
    {
        public abstract ServicioClinico CrearServicio(string[] datos);
    }

    public class FabricaServicioClinico : FabricaServicio
    {
        public override ServicioClinico CrearServicio(string[] datos)
        {
            return new ServicioClinico(
                datos[0],
                decimal.Parse(datos[1]),
                datos.Length > 2 ? datos[2] : string.Empty);
        }

        public ServicioClinico Crear(string nombre, decimal precio, string descripcion)
        {
            return new ServicioClinico(nombre, precio, descripcion);
        }
    }
}
