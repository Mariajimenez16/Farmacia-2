using System;
using BibFarmacia.Clases;

namespace BibFarmacia.Factories
{
    public class FabricaCosmetico : FabricaProducto
    {
        public override Producto CrearProducto(string[] datos)
        {
            return new Cosmetico(
                datos[0],
                decimal.Parse(datos[1]),
                int.Parse(datos[2]),
                int.Parse(datos[3]),
                DateTime.Parse(datos[4]),
                datos[5]);
        }

        public Cosmetico Crear(
            string nombre,
            decimal precio,
            int stock,
            string marca,
            int stockMinimo = 5,
            DateTime? fechaVencimiento = null)
        {
            return new Cosmetico(
                nombre,
                precio,
                stock,
                stockMinimo,
                fechaVencimiento ?? DateTime.Now.AddMonths(12),
                marca);
        }
    }
}
