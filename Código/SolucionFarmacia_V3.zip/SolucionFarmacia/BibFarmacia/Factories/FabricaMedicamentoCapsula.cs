using System;
using BibFarmacia.Clases;
using BibFarmacia.Enum;

namespace BibFarmacia.Factories
{
    public class FabricaMedicamentoCapsula : FabricaProducto
    {
        public override Producto CrearProducto(string[] datos)
        {
            Laboratorio lab = new Laboratorio(
                datos.Length > 5 ? datos[5] : "General",
                datos.Length > 6 ? datos[6] : "Medellin",
                datos.Length > 7 ? datos[7] : "4444444");

            TipoRelleno relleno = TipoRelleno.Gel;
            if (datos.Length > 8 && System.Enum.TryParse<TipoRelleno>(datos[8], true, out var r))
            {
                relleno = r;
            }

            return new MedicamentoCapsula(
                datos[0],
                decimal.Parse(datos[1]),
                int.Parse(datos[2]),
                int.Parse(datos[3]),
                DateTime.Parse(datos[4]),
                lab,
                relleno);
        }

        public MedicamentoCapsula Crear(
            string nombre,
            decimal precio,
            int stock,
            Laboratorio laboratorio,
            int stockMinimo = 5,
            DateTime? fechaVencimiento = null,
            TipoRelleno tipoRelleno = TipoRelleno.Gel)
        {
            return new MedicamentoCapsula(
                nombre,
                precio,
                stock,
                stockMinimo,
                fechaVencimiento ?? DateTime.Now.AddMonths(6),
                laboratorio,
                tipoRelleno);
        }
    }
}
