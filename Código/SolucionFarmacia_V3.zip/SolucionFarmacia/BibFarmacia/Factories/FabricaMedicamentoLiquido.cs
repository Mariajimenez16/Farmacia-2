using System;
using BibFarmacia.Clases;
using BibFarmacia.Enum;

namespace BibFarmacia.Factories
{
    public class FabricaMedicamentoLiquido : FabricaProducto
    {
        public override Producto CrearProducto(string[] datos)
        {
            Laboratorio lab = new Laboratorio(
                datos.Length > 5 ? datos[5] : "General",
                datos.Length > 6 ? datos[6] : "Medellin",
                datos.Length > 7 ? datos[7] : "4444444");

            MaterialEnvase envase = MaterialEnvase.Vidrio;
            if (datos.Length > 8 && System.Enum.TryParse<MaterialEnvase>(datos[8], true, out var e))
            {
                envase = e;
            }

            int volumen = datos.Length > 9 ? int.Parse(datos[9]) : 120;

            return new MedicamentoLiquido(
                datos[0],
                decimal.Parse(datos[1]),
                int.Parse(datos[2]),
                int.Parse(datos[3]),
                DateTime.Parse(datos[4]),
                lab,
                envase,
                volumen);
        }

        public MedicamentoLiquido Crear(
            string nombre,
            decimal precio,
            int stock,
            Laboratorio laboratorio,
            int stockMinimo = 5,
            DateTime? fechaVencimiento = null,
            MaterialEnvase materialEnvase = MaterialEnvase.Vidrio,
            int volumenMl = 120)
        {
            return new MedicamentoLiquido(
                nombre,
                precio,
                stock,
                stockMinimo,
                fechaVencimiento ?? DateTime.Now.AddMonths(12),
                laboratorio,
                materialEnvase,
                volumenMl);
        }
    }
}
