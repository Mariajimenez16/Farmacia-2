using System;
using BibFarmacia.Clases;

namespace BibFarmacia.Factories
{
    public class FabricaComestible : FabricaProducto
    {
        public override Producto CrearProducto(string[] datos)
        {
            return new Comestible(
                datos[0],
                decimal.Parse(datos[1]),
                int.Parse(datos[2]),
                int.Parse(datos[3]),
                DateTime.Parse(datos[4]),
                int.Parse(datos[5]));
        }

        public Comestible Crear(
            string nombre,
            decimal precio,
            int stock,
            int calorias,
            int stockMinimo = 5,
            DateTime? fechaVencimiento = null)
        {
            return new Comestible(
                nombre,
                precio,
                stock,
                stockMinimo,
                fechaVencimiento ?? DateTime.Now.AddMonths(12),
                calorias);
        }
    }
}
