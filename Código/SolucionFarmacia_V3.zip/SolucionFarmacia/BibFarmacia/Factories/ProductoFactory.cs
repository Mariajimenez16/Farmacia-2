using BibFarmacia.Clases;
using BibFarmacia.Enum;
using System;

namespace BibFarmacia.Factories
{
    public static class ProductoFactory
    {
        private static readonly FabricaMedicamentoCapsula fabricaCapsula = new FabricaMedicamentoCapsula();
        private static readonly FabricaMedicamentoLiquido fabricaLiquido = new FabricaMedicamentoLiquido();

        public static MedicamentoCapsula CrearCapsula(
            string nombre,
            decimal precio,
            int stock,
            Laboratorio laboratorio)
        {
            return fabricaCapsula.Crear(nombre, precio, stock, laboratorio);
        }

        public static MedicamentoLiquido CrearLiquido(
            string nombre,
            decimal precio,
            int stock,
            Laboratorio laboratorio)
        {
            return fabricaLiquido.Crear(nombre, precio, stock, laboratorio);
        }
    }
}