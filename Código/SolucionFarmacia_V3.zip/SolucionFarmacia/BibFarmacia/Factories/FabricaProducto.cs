using BibFarmacia.Clases;

namespace BibFarmacia.Factories
{
    public abstract class FabricaProducto
    {
        public abstract Producto CrearProducto(string[] datos);
    }
}
